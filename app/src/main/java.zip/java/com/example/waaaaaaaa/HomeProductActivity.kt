package com.example.waaaaaaaa

import Product
import ProductAdapter
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView


class HomeProductActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_home_product)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val listProduct = findViewById<RecyclerView>(R.id.listProduct_view)
        val listData = listOf(
            Product(R.mipmap.ic_launcher, "Điện thoại SamSung", "25.490.000đ"),
            Product(R.mipmap.ic_launcher, "Điện thoại Iphone", "35.890.000đ"),
            Product(R.mipmap.ic_launcher, "Điện thoại ViVo", "15.790.000đ"),
            Product(R.mipmap.ic_launcher, "Điện thoại OPPO", "13.990.000đ"),
            Product(R.mipmap.ic_launcher, "Điện thoại REDMI", "21.390.000đ")
        )
        val productAdapter = ProductAdapter(listData) { product ->
            Toast.makeText(this, "Bạn đã chọn mua: ${product.name}", Toast.LENGTH_SHORT).show()
        }
        listProduct.layoutManager = LinearLayoutManager(this)
        listProduct.adapter = productAdapter

    }
}