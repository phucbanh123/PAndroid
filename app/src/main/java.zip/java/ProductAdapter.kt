import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import com.example.waaaaaaaa.R
import androidx.recyclerview.widget.RecyclerView

class ProductAdapter(private val productlist: List<Product>,
                     private val onItemClick: (Product) -> Unit ): RecyclerView.Adapter<ProductAdapter.ViewHolder>(){
    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        val imgProduct: ImageView = itemView.findViewById(R.id.imgProduct)
        val nameProduct: TextView = itemView.findViewById(R.id.nameProduct)
        val priceProduct: TextView = itemView.findViewById(R.id.priceProduct)
    }
    override fun onCreateViewHolder(
        p0: ViewGroup,
        p1: Int
    ): ViewHolder {
        val View = LayoutInflater.from(p0.context)
            .inflate(R.layout.item_product, p0, false)
        return ViewHolder(View)
    }

    override fun onBindViewHolder(p0: ViewHolder, p1: Int) {
        val product = productlist[p1]

        p0.nameProduct.text = product.name
        p0.priceProduct.text = product.price
        p0.imgProduct.setImageResource(product.image)
        p0.itemView.setOnClickListener {
            onItemClick(product)
        }
    }

    override fun getItemCount(): Int = productlist.size
}
