class Product (
    val image: Int,
    val name: String,
    val price: String
)